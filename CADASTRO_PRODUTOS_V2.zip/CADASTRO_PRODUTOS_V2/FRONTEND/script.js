
class Produto {
  #preco;
  #quantidade;
  #id; 

  constructor(nome, preco, quantidade, id = null) {
    if (!nome || preco <= 0 || quantidade <= 0) {
      throw new Error("Dados inválidos para o produto.");
    }
    this.#id = id; 
    this.nome = nome;
    this.#preco = parseFloat(preco);
    this.#quantidade = parseInt(quantidade, 10);
  }

  get id() {
    return this.#id;
  }

  get preco() {
    return this.#preco;
  }

  get quantidade() {
    return this.#quantidade;
  }

  valorTotal() {
    return this.#preco * this.#quantidade;
  }

  toJSON() {
    return {
      id: this.#id, 
      nome: this.nome,
      preco: this.#preco,
      quantidade: this.#quantidade
    };
  }
}

const API_URL = "http://localhost:3000/produtos";
const AUTH_URL = "http://localhost:3000/auth";


function obterHeadersAutenticados() {
  const token = localStorage.getItem("token_produtos");
  return {
    "Content-Type": "application/json",
    "Authorization": token ? `Bearer ${token}` : ""
  };
}


document.getElementById("produto-form").addEventListener("submit", async function (e) {
  e.preventDefault();

  const nome = document.getElementById("nome").value;
  const preco = document.getElementById("preco").value;
  const quantidade = document.getElementById("quantidade").value;

  try {
    const novoProduto = new Produto(nome, preco, quantidade);

    const resposta = await fetch(API_URL, {
      method: "POST",
      headers: obterHeadersAutenticados(), 
      body: JSON.stringify(novoProduto.toJSON())
    });

    const respostaDados = await resposta.json();

    if (!resposta.ok) {
      throw new Error(respostaDados.erro || "Erro ao salvar o produto no servidor backend.");
    }

    renderizarTabela();
    e.target.reset();
  } catch (erro) {
    alert(erro.message);
  }
});


async function renderizarTabela() {
  try {
    const resposta = await fetch(API_URL);
    const dadosBrutosDoServidor = await resposta.json();

    const tabela = document.querySelector("#tabela-produtos tbody");
    if (!tabela) return;
    tabela.innerHTML = ""; 

    let totalAcumulado = 0;

    dadosBrutosDoServidor.forEach((dados) => {
      const produto = new Produto(dados.nome, dados.preco, dados.quantidade, dados.id);

      totalAcumulado += produto.valorTotal();

      const row = document.createElement("tr");
      
      row.innerHTML = `
        <td>${produto.nome}</td>
        <td>R$ ${produto.preco.toFixed(2)}</td>
        <td>${produto.quantidade}</td>
        <td>R$ ${produto.valorTotal().toFixed(2)}</td>
        <td>
          <button class="btn-excluir" style="cursor:pointer; color:red;">❌ Excluir</button>
        </td>
      `;

      row.querySelector(".btn-excluir").addEventListener("click", function() {
        excluirItemUnico(produto.id);
      });

      tabela.appendChild(row);
    });

    document.getElementById("total-estoque").textContent = `Total em estoque: R$ ${totalAcumulado.toFixed(2)}`;
  } catch (erro) {
    console.error("Erro ao buscar dados no servidor:", erro);
  }
}


async function excluirItemUnico(id) {
  if (!id) {
    alert("Este produto não possui um identificador válido no servidor.");
    return;
  }

  if (confirm("Deseja mesmo excluir este item específico?")) {
    try {
      const resposta = await fetch(`${API_URL}/${id}`, {
        method: "DELETE",
        headers: obterHeadersAutenticados() 
      });

      if (!resposta.ok) {
        const respostaDados = await resposta.json().catch(() => ({}));
        throw new Error(respostaDados.erro || "Erro ao excluir o produto no servidor. Verifique se você é um Administrador.");
      }

      renderizarTabela();
    } catch (erro) {
      console.error("Erro ao deletar o produto:", erro);
      alert(erro.message);
    }
  }
}


document.getElementById("limpar-tabela").addEventListener("click", async function () {
  if (confirm("Deseja mesmo limpar toda a tabela no servidor?")) {
    try {
      const resposta = await fetch(API_URL, { 
        method: "DELETE",
        headers: obterHeadersAutenticados() // Injeção do Token e verificação de Admin
      });

      if (!resposta.ok) {
        const respostaDados = await resposta.json().catch(() => ({}));
        throw new Error(respostaDados.erro || "Erro ao limpar dados no servidor. Verifique se você é um Administrador.");
      }

      renderizarTabela();
    } catch (erro) {
      console.error("Erro ao limpar dados no servidor:", erro);
      alert(erro.message);
    }
  }
});


const formRegistro = document.getElementById("registro-form");
if (formRegistro) {
  formRegistro.addEventListener("submit", async function (e) {
    e.preventDefault();
    
    const nome = document.getElementById("reg-nome").value;
    const email = document.getElementById("reg-email").value;
    const senha = document.getElementById("reg-senha").value;
    const perfil = document.getElementById("reg-perfil").value; 

    try {
      const resposta = await fetch(`${AUTH_URL}/registro`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, email, senha, perfil })
      });

      const dados = await resposta.json();

      if (!resposta.ok) {
        throw new Error(dados.erro || "Erro ao realizar o cadastro.");
      }

      alert("Cadastro realizado com sucesso! Faça login para continuar.");
      formRegistro.reset();
    } catch (erro) {
      alert(erro.message);
    }
  });
}

const formLogin = document.getElementById("login-form");
if (formLogin) {
  formLogin.addEventListener("submit", async function (e) {
    e.preventDefault();

    const email = document.getElementById("login-email").value;
    const senha = document.getElementById("login-senha").value;

    try {
      const resposta = await fetch(`${AUTH_URL}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, senha })
      });

      const dados = await resposta.json();

      if (!resposta.ok) {
        throw new Error(dados.erro || "E-mail ou senha incorretos.");
      }

    
      localStorage.setItem("token_produtos", dados.token);
      
      alert(`Bem-vindo, ${dados.usuario.nome}! Perfil: ${dados.usuario.perfil}`);
      formLogin.reset();
  
      renderizarTabela();
    } catch (erro) {
      alert(erro.message);
    }
  });
}

r
const btnLogout = document.getElementById("btn-logout");
if (btnLogout) {
  btnLogout.addEventListener("click", function() {
    localStorage.removeItem("token_produtos");
    alert("Você saiu do sistema.");
    renderizarTabela();
  });
}

renderizarTabela();

