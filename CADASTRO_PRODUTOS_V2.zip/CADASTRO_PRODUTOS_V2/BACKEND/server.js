const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose(); 
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = 3000;
const JWT_SECRET = 'sua_chave_secreta_super_segura_aqui'; 
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'DELETE', 'PUT', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());

const db = new sqlite3.Database('./produtos.db', (err) => {
    if (err) {
        console.error("Erro ao conectar ao banco de dados:", err.message);
    } else {
        console.log("Conectado com sucesso ao banco de dados SQLite (produtos.db).");
    }
});


db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            preco REAL NOT NULL,
            quantidade INTEGER NOT NULL
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            senha TEXT NOT NULL,
            perfil TEXT NOT NULL CHECK(perfil IN ('admin', 'cliente'))
        )
    `);
});


function verificarAutenticacao(req, res, next) {
    const authHeader = req.headers['authorization'];
    
    if (!authHeader) {
        return res.status(401).json({ erro: "Token de autenticação não fornecido." });
    }

    const partes = authHeader.split(' ');
    if (partes.length !== 2 || partes[0] !== 'Bearer') {
        return res.status(401).json({ erro: "Token mal formatado. Formato esperado: Bearer <TOKEN>" });
    }

    const token = partes[1];

    jwt.verify(token, JWT_SECRET, (err, decoded) => {
        if (err) {
            return res.status(403).json({ erro: "Token inválido ou expirado." });
        }
      
        req.usuarioLogado = decoded;
        next();
    });
}
function verificarAdmin(req, res, next) {
    if (!req.usuarioLogado || req.usuarioLogado.perfil !== 'admin') {
        return res.status(403).json({ erro: "Acesso negado. Recurso exclusivo para administradores." });
    }
    next();
}

app.post('/auth/registro', async (req, res) => {
    const { nome, email, senha, perfil } = req.body;

    if (!nome || !email || !senha || !perfil) {
        return res.status(400).json({ erro: "Todos os campos (nome, email, senha, perfil) são obrigatórios." });
    }

    if (perfil !== 'admin' && perfil !== 'cliente') {
        return res.status(400).json({ erro: "O perfil deve ser obligatoriamente 'admin' ou 'cliente'." });
    }

    try {
        
        const salt = await bcrypt.genSalt(10);
        const senhaCriptografada = await bcrypt.hash(senha, salt);

        const sql = "INSERT INTO usuarios (nome, email, senha, perfil) VALUES (?, ?, ?, ?)";
        
        db.run(sql, [nome, email, senhaCriptografada, perfil], function(err) {
            if (err) {
                if (err.message.includes("UNIQUE constraint failed")) {
                    return res.status(400).json({ erro: "Este e-mail já está cadastrado." });
                }
                return res.status(500).json({ erro: err.message });
            }

            res.status(201).json({
                mensagem: "Usuário cadastrado com sucesso!",
                usuario: { id: this.lastID, nome, email, perfil }
            });
        });
    } catch (error) {
        res.status(500).json({ erro: "Erro interno ao processar a senha." });
    }
});


app.post('/auth/login', (req, res) => {
    const { email, senha } = req.body;

    if (!email || !senha) {
        return res.status(400).json({ erro: "E-mail e senha são obrigatórios." });
    }

    db.get("SELECT * FROM usuarios WHERE email = ?", [email], async (err, usuario) => {
        if (err) {
            return res.status(500).json({ erro: err.message });
        }
        if (!usuario) {
            return res.status(401).json({ erro: "E-mail ou senha incorretos." });
        }

        
        const senhaValida = await bcrypt.compare(senha, usuario.senha);
        if (!senhaValida) {
            return res.status(401).json({ erro: "E-mail ou senha incorretos." });
        }

        
        const token = jwt.sign(
            { id: usuario.id, perfil: usuario.perfil },
            JWT_SECRET,
            { expiresIn: '2h' }
        );

        res.status(200).json({
            mensagem: "Login efetuado com sucesso!",
            token,
            usuario: { nome: usuario.nome, perfil: usuario.perfil }
        });
    });
});


app.get('/produtos', (req, res) => {
    db.all("SELECT * FROM produtos", [], (err, rows) => {
        if (err) {
            return res.status(500).json({ erro: err.message });
        }
        res.status(200).json(rows);
    });
});


app.post('/produtos', verificarAutenticacao, (req, res) => {
    const { nome, preco, quantidade } = req.body;

    const p = parseFloat(preco);
    const q = parseInt(quantidade);

    if (!nome || isNaN(p) || isNaN(q) || p <= 0 || q <= 0) {
        return res.status(400).json({ erro: "Dados inválidos enviados para o servidor" });
    }

    const sql = "INSERT INTO produtos (nome, preco, quantidade) VALUES (?, ?, ?)";
    
    db.run(sql, [nome, p, q], function(err) {
        if (err) {
            return res.status(500).json({ erro: err.message });
        }

        const novoItem = {
            id: this.lastID, 
            nome,
            preco: p,
            quantidade: q
        };

        res.status(201).json(novoItem);
    });
});


app.delete('/produtos', verificarAutenticacao, verificarAdmin, (req, res) => {
    db.run("DELETE FROM produtos", [], function(err) {
        if (err) {
            return res.status(500).json({ erro: err.message });
        }
        res.status(204).send();
    });
});


app.delete('/produtos/:id', verificarAutenticacao, verificarAdmin, (req, res) => {
    const idParaExcluir = parseInt(req.params.id);
    
    db.get("SELECT id FROM produtos WHERE id = ?", [idParaExcluir], (err, row) => {
        if (err) {
            return res.status(500).json({ erro: err.message });
        }
        if (!row) {
            return res.status(404).json({ erro: "Produto não encontrado no servidor" });
        }

        db.run("DELETE FROM produtos WHERE id = ?", [idParaExcluir], function(err) {
            if (err) {
                return res.status(500).json({ erro: err.message });
            }
            res.status(204).send();
        });
    });
});

app.listen(PORT, () => {
    console.log(`Servidor backend rodando em http://localhost:${PORT}`);
});

